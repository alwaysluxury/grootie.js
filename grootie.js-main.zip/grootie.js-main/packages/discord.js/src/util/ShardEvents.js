'use strict';

module.exports = {
  Close: 'close',
  Destroyed: 'destroyed',
  InvalidSession: 'invalidSession',
  Ready: 'ready',
  Resumed: 'resumed',
  AllReady: 'allReady',
};
