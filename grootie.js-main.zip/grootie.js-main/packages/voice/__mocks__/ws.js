export { WebSocket as default } from 'mock-socket';
